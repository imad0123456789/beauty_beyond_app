export interface User{
  email? : string,
  name? : string,
  family?: string,
  age?: number,
  mobileNumber?: number,
  password? :string,
}
