
export interface Booking {
  Date?: string,
  day?: string,
  Time?: string,
  DoctorCategory? : string,
  doctorId?: string,
  doctorName?: string,
  status?: string,
  userId: string,
}
