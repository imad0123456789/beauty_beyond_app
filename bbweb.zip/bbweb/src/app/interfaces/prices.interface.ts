
export interface Price {
  id?: string,
  name?: string,
  price?: string,
  photoUrl: string,

}
