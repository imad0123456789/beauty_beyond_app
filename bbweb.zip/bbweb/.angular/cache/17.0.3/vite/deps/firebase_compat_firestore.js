import "./chunk-IXBAVEAS.js";
import "./chunk-36HXBO72.js";
import "./chunk-EQU7RARR.js";
//# sourceMappingURL=firebase_compat_firestore.js.map
