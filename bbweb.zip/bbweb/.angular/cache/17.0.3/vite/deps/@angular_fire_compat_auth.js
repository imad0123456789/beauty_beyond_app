import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-HC2YBSAL.js";
import "./chunk-JOGB22HU.js";
import "./chunk-KK6GXKII.js";
import "./chunk-ZIXXBJYE.js";
import "./chunk-OIL6NKHX.js";
import "./chunk-LHRTKJE6.js";
import "./chunk-676J6N46.js";
import "./chunk-36HXBO72.js";
import "./chunk-EQU7RARR.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
//# sourceMappingURL=@angular_fire_compat_auth.js.map
