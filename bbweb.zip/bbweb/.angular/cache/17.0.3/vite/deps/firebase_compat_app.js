import "./chunk-676J6N46.js";
import {
  firebase
} from "./chunk-36HXBO72.js";
import "./chunk-EQU7RARR.js";
export {
  firebase as default
};
//# sourceMappingURL=firebase_compat_app.js.map
