export const firebaseconfig = {
  apiKey: "AIzaSyACINTDtcQRYY8DxDL8uCPhJ7WdgEQduO4",
  authDomain: "bb-app-b5395.firebaseangpp.com",
  projectId: "bb-app-b5395",
  storageBucket: "bb-app-b5395.appspot.com",
  messagingSenderId: "bb-app-b5395.appspot.com",
  appId: "1:2847857653:android:6b1244ece8fee18fcd5ebc",
  measurementId: ""
}
